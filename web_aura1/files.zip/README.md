# Aura — belleza pura

Página web de **Aura**, cosmetología y estética facial · Tortuguitas, Zona Norte, Buenos Aires.
Instagram: [@aura_esttetica](https://www.instagram.com/aura_esttetica/)

## Qué hay en este repositorio

| Archivo | Para qué sirve |
|---|---|
| `index.html` | La página completa (diseño, textos y fotos incluidas). **Es lo único imprescindible.** |
| `og-image.jpg` | Foto que se muestra al compartir el link en WhatsApp o redes (opcional). |
| `robots.txt` | Permite que Google encuentre la página. |
| `README.md` | Este archivo. |

## Publicarla (GitHub Pages)

1. En este repositorio andá a **Settings → Pages**.
2. En *Source* elegí **Deploy from a branch**.
3. En *Branch* elegí **main** y la carpeta **/(root)**. Tocá **Save**.
4. En uno o dos minutos aparece el link: `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`

## Actualizar la página

Entrá al repositorio → **Add file → Upload files** → subí el nuevo `index.html` (mismo nombre) → **Commit changes**.
El link no cambia.

## Editar textos, tratamientos y fotos

Abrí `index.html` y buscá el bloque **CONTENIDO EDITABLE** (cerca del final del archivo):

- `TRATAMIENTOS`: nombres, descripciones y beneficios. Podés agregar `precio:"..."` y `duracion:"..."` a cada tratamiento.
- `MARCAS`: marcas con las que trabajás.
- `ESPACIO`: fotos de la galería de "Mi espacio".
- `IMG`: las fotos están incrustadas en el archivo. Para usar una foto propia, subila al repositorio (por ejemplo dentro de una carpeta `img/`) y reemplazá el valor, por ejemplo `IMG["dermapen"]="img/mi-foto.jpg"`.

## Foto al compartir el link (opcional)

En el `<head>` de `index.html` hay un bloque comentado con `og:image`. Reemplazá `TU-USUARIO` y `TU-REPO` por los tuyos y quitá `<!--` y `-->`.
